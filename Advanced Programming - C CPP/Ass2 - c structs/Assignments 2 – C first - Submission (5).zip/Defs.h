#include <stdio.h>
typedef enum e_bool{true,false} boolean;
typedef enum e_status{success,failure} status;