package assignment2;

public interface EdgePointer {
    public double getLeftMostX();
    public double getUpperMostY();
}
