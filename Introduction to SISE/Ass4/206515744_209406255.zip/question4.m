function f = question4(x)
if x < 0
    f = -1;
elseif x == 0
    f = 0;
else 
    f = 1;
end
